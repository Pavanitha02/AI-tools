# Design Guidelines: Personal Portfolio Website

## Design Approach
**Reference-Based Design**: Drawing inspiration from modern portfolio sites like Linear (clean typography), Stripe (refined simplicity), and Vercel (bold hero presence). Focus on creating a professional yet personal aesthetic that showcases personality through layout and typography rather than excessive decoration.

## Typography System
- **Headings**: Google Fonts "Inter" (700 weight) for hero headline and section titles
- **Body/Navigation**: "Inter" (400-500 weight) for all other text
- **Sizing Scale**: 
  - Hero headline: text-5xl md:text-6xl lg:text-7xl
  - Section titles: text-3xl md:text-4xl
  - Body text: text-base md:text-lg
  - Navigation: text-sm md:text-base

## Spacing System
Use Tailwind units: **4, 6, 8, 12, 16, 20, 24** for consistent rhythm
- Section padding: py-16 md:py-24 lg:py-32
- Component spacing: gap-6 md:gap-8
- Container max-width: max-w-6xl mx-auto px-6

## Layout Structure

### Header (sticky position)
- Full-width with max-w-6xl container
- Logo/name on left, navigation on right
- Desktop: Horizontal nav with gap-8
- Mobile (<768px): Hamburger menu icon, slide-in overlay navigation
- Height: h-16 md:h-20, backdrop blur effect

### Hero Section
- **Large hero image**: Full-width background image (professional workspace, city skyline, or abstract tech-themed image), subtle dark overlay for text contrast
- Content centered with max-w-4xl
- Headline with strong hierarchy (7xl on desktop)
- Description max-width: max-w-2xl for readability
- "Contact Me" button with **backdrop-blur-md background**, prominent size (px-8 py-4), elevated with shadow

### Skills Section
- Grid layout with responsive columns:
  - Mobile: grid-cols-1
  - Tablet: grid-cols-2  
  - Desktop: grid-cols-3
- Minimum 6 skill cards, each with:
  - Icon (use Heroicons via CDN)
  - Skill name (text-lg font-semibold)
  - Optional brief description (text-sm)
  - Card padding: p-6, rounded-xl, subtle border
- Gap between cards: gap-6

### Footer
- 2-row layout:
  - Social media icons row (gap-6, size-6 icons from Heroicons)
  - Copyright/attribution text (text-sm)
- Center-aligned content
- Padding: py-12

## Component Specifications

**Navigation Links**
- Spacing: gap-8 on desktop
- Underline animation on hover (transition-all duration-300)
- Active state: slightly bolder weight

**Contact Me Button**
- Prominent CTA styling with backdrop-blur-md
- Size: px-8 py-4 text-lg
- Rounded: rounded-full
- Shadow: shadow-lg
- No hover/active states defined (component handles internally)

**Skill Cards**
- Border style: border with subtle width
- Rounded corners: rounded-xl
- Padding: p-6
- Icon at top, text content below
- Vertical spacing within card: space-y-3

## Images
- **Hero Background**: Professional full-width image (1920x1080 minimum) - workspace, cityscape, or abstract tech aesthetic with subtle dark gradient overlay (opacity-50) for text readability
- **Skill Icons**: Use Heroicons library via CDN - select icons like CodeBracketIcon, CommandLineIcon, DevicePhoneIcon, etc.

## Responsive Behavior
- **Mobile-first approach**: Base styles for mobile, override with md: and lg: breakpoints
- **No horizontal scroll**: All content constrained within viewport
- **Touch targets**: Minimum 44x44px for mobile interactions
- **Hamburger menu**: Slide-in from right, full-height overlay, close icon in top-right

## Accessibility
- Semantic HTML5 tags (header, main, section, footer)
- ARIA labels for hamburger menu and social links
- Focus visible states on all interactive elements
- Sufficient contrast ratios maintained throughout