import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Menu, X, Code2, Palette, Smartphone, Database, Cloud, Zap, Github, Linkedin, Twitter, Mail } from "lucide-react";
import heroImage from "@assets/generated_images/professional_workspace_hero_background.png";

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  const skills = [
    {
      icon: Code2,
      name: "Web Development",
      description: "Building responsive and performant web applications"
    },
    {
      icon: Palette,
      name: "UI/UX Design",
      description: "Creating beautiful and intuitive user experiences"
    },
    {
      icon: Smartphone,
      name: "Mobile Development",
      description: "Native and cross-platform mobile solutions"
    },
    {
      icon: Database,
      name: "Database Design",
      description: "Architecting scalable data solutions"
    },
    {
      icon: Cloud,
      name: "Cloud Services",
      description: "Deploying and managing cloud infrastructure"
    },
    {
      icon: Zap,
      name: "Performance Optimization",
      description: "Making applications lightning fast"
    }
  ];

  const socialLinks = [
    { icon: Github, href: "#", label: "GitHub" },
    { icon: Linkedin, href: "#", label: "LinkedIn" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Mail, href: "mailto:hello@example.com", label: "Email" }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md" data-testid="header">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo/Name */}
            <a 
              href="#" 
              className="text-xl md:text-2xl font-bold text-foreground hover-elevate active-elevate-2 px-3 py-2 -ml-3 rounded-md transition-all"
              data-testid="logo"
            >
              Portfolio
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8" data-testid="nav-desktop">
              <button
                onClick={() => scrollToSection("home")}
                className="text-sm md:text-base text-foreground hover:text-primary transition-all duration-300 relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
                data-testid="link-home"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="text-sm md:text-base text-foreground hover:text-primary transition-all duration-300 relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
                data-testid="link-about"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("skills")}
                className="text-sm md:text-base text-foreground hover:text-primary transition-all duration-300 relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
                data-testid="link-skills"
              >
                Skills
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-sm md:text-base text-foreground hover:text-primary transition-all duration-300 relative after:absolute after:bottom-0 after:left-0 after:h-0.5 after:w-0 after:bg-primary after:transition-all after:duration-300 hover:after:w-full"
                data-testid="link-contact"
              >
                Contact
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
              data-testid="button-menu-toggle"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation Overlay */}
        {mobileMenuOpen && (
          <div 
            className="md:hidden fixed inset-0 top-16 bg-background/95 backdrop-blur-md z-40 animate-in slide-in-from-right"
            data-testid="nav-mobile"
          >
            <nav className="flex flex-col p-6 gap-6">
              <button
                onClick={() => scrollToSection("home")}
                className="text-lg text-foreground hover:text-primary transition-all py-3 text-left border-b border-border"
                data-testid="link-home-mobile"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="text-lg text-foreground hover:text-primary transition-all py-3 text-left border-b border-border"
                data-testid="link-about-mobile"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("skills")}
                className="text-lg text-foreground hover:text-primary transition-all py-3 text-left border-b border-border"
                data-testid="link-skills-mobile"
              >
                Skills
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-lg text-foreground hover:text-primary transition-all py-3 text-left border-b border-border"
                data-testid="link-contact-mobile"
              >
                Contact
              </button>
            </nav>
          </div>
        )}
      </header>

      <main>
        {/* Hero Section */}
        <section 
          id="home"
          className="relative min-h-[600px] md:min-h-[700px] lg:min-h-[800px] flex items-center justify-center overflow-hidden"
          data-testid="section-hero"
        >
          {/* Background Image with Dark Overlay */}
          <div className="absolute inset-0 z-0">
            <img 
              src={heroImage} 
              alt="Hero background" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/60"></div>
          </div>

          {/* Content */}
          <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
            <h1 
              className="text-5xl md:text-6xl lg:text-7xl font-bold text-white mb-6 md:mb-8 leading-tight"
              data-testid="text-hero-headline"
            >
              Building Digital Experiences
            </h1>
            <p 
              className="text-base md:text-lg lg:text-xl text-white/90 max-w-2xl mx-auto mb-8 md:mb-12 leading-relaxed"
              data-testid="text-hero-description"
            >
              I'm a passionate developer crafting beautiful, functional, and user-centered digital solutions. Let's create something amazing together.
            </p>
            <Button
              size="lg"
              onClick={() => scrollToSection("contact")}
              className="px-8 py-6 text-lg rounded-full shadow-lg bg-primary/90 backdrop-blur-md border border-primary-border text-primary-foreground"
              data-testid="button-contact-me"
            >
              Contact Me
            </Button>
          </div>
        </section>

        {/* About Section (Placeholder for navigation) */}
        <section 
          id="about" 
          className="py-16 md:py-24 lg:py-32 bg-card"
          data-testid="section-about"
        >
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-card-foreground">
              About Me
            </h2>
            <div className="max-w-3xl mx-auto">
              <p className="text-base md:text-lg text-muted-foreground leading-relaxed text-center">
                With a passion for innovation and a keen eye for detail, I specialize in transforming ideas into exceptional digital products. My expertise spans across modern web technologies, design principles, and scalable architecture.
              </p>
            </div>
          </div>
        </section>

        {/* Skills Section */}
        <section 
          id="skills" 
          className="py-16 md:py-24 lg:py-32 bg-background"
          data-testid="section-skills"
        >
          <div className="max-w-6xl mx-auto px-6">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 md:mb-16 text-foreground">
              Skills & Expertise
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" data-testid="skills-grid">
              {skills.map((skill, index) => {
                const Icon = skill.icon;
                return (
                  <Card 
                    key={index} 
                    className="p-6 rounded-xl border border-card-border hover-elevate active-elevate-2 transition-all"
                    data-testid={`card-skill-${index}`}
                  >
                    <div className="space-y-3">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-card-foreground">
                        {skill.name}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {skill.description}
                      </p>
                    </div>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Contact Section (Placeholder for navigation) */}
        <section 
          id="contact" 
          className="py-16 md:py-24 lg:py-32 bg-card"
          data-testid="section-contact"
        >
          <div className="max-w-6xl mx-auto px-6 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-card-foreground">
              Let's Work Together
            </h2>
            <p className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto mb-12">
              Have a project in mind? I'd love to hear from you. Get in touch and let's discuss how we can bring your ideas to life.
            </p>
            <Button
              size="lg"
              onClick={() => window.location.href = "mailto:hello@example.com"}
              className="px-8 py-6 text-lg rounded-full"
              data-testid="button-email"
            >
              <Mail className="w-5 h-5 mr-2" />
              Send an Email
            </Button>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-12 bg-background border-t border-border" data-testid="footer">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col items-center gap-6">
            {/* Social Media Links */}
            <div className="flex items-center gap-6">
              {socialLinks.map((link, index) => {
                const Icon = link.icon;
                return (
                  <a
                    key={index}
                    href={link.href}
                    aria-label={link.label}
                    className="w-10 h-10 rounded-lg bg-card border border-card-border flex items-center justify-center text-muted-foreground hover:text-primary hover-elevate active-elevate-2 transition-all"
                    data-testid={`link-social-${link.label.toLowerCase()}`}
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                );
              })}
            </div>

            {/* Copyright */}
            <p className="text-sm text-muted-foreground text-center">
              © 2025 Portfolio. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
